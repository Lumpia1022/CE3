package com.example.accountmanagement
import android.annotation.SuppressLint
import android.content.Intent

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


data class AccountModel(val id: Int, val platform: String, val profileLink: String, val phone: String, val email: String, val password: String)
class DatabaseHandler(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "AccountDatabase"
        private const val TABLE_ACCOUNTS = "Accounts"

        private const val KEY_ID = "id"
        private const val KEY_PLATFORM = "platform"
        private const val KEY_PROFILE_LINK = "profile_link"
        private const val KEY_PHONE = "phone"
        private const val KEY_EMAIL = "email"
        private const val KEY_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = ("CREATE TABLE $TABLE_ACCOUNTS($KEY_ID INTEGER PRIMARY KEY,$KEY_PLATFORM TEXT,$KEY_PROFILE_LINK TEXT,$KEY_PHONE TEXT,$KEY_EMAIL TEXT,$KEY_PASSWORD TEXT)")
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ACCOUNTS")
        onCreate(db)
    }

    fun addAccount(account: AccountModel): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(KEY_PLATFORM, account.platform)
        contentValues.put(KEY_PROFILE_LINK, account.profileLink)
        contentValues.put(KEY_PHONE, account.phone)
        contentValues.put(KEY_EMAIL, account.email)
        contentValues.put(KEY_PASSWORD, account.password)

        val success = db.insert(TABLE_ACCOUNTS, null, contentValues)
        db.close()
        return success
    }
}

class add_account : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")


        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            enableEdgeToEdge()
            setContentView(R.layout.activity_add_account)
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
            fun saveRecord() {
                val platform = findViewById<EditText>(R.id.platform).text.toString()
                val profileLink = findViewById<EditText>(R.id.profile_link).text.toString()
                val phone = findViewById<EditText>(R.id.phone).text.toString()
                val email = findViewById<EditText>(R.id.email).text.toString()
                val password = findViewById<EditText>(R.id.password).text.toString()
                val databaseHandler = DatabaseHandler(this)

                if (platform.trim().isNotEmpty() && profileLink.trim().isNotEmpty() && phone.trim().isNotEmpty() && email.trim().isNotEmpty() && password.trim().isNotEmpty()) {
                    val status = databaseHandler.addAccount(AccountModel(0, platform, profileLink, phone, email, password))
                    if (status > -1) {
                        Toast.makeText(applicationContext, "Record saved", Toast.LENGTH_LONG).show()
                        findViewById<EditText>(R.id.platform).text.clear()
                        findViewById<EditText>(R.id.profile_link).text.clear()
                        findViewById<EditText>(R.id.phone).text.clear()
                        findViewById<EditText>(R.id.email).text.clear()
                        findViewById<EditText>(R.id.password).text.clear()

                        // Redirect to Accounts activity if needed
                        val intent = Intent(this, Accounts::class.java)
                        startActivity(intent)
                    }
                } else {
                    Toast.makeText(applicationContext, "All fields are required", Toast.LENGTH_LONG).show()
                }
            }

            val submitbtn: Button = findViewById(R.id.submitbtn)

            submitbtn.setOnClickListener() {
                saveRecord()
                val intent = Intent(this, Accounts::class.java)
                startActivity(intent)

            }


        }
    }
class ListAdapter(private val platform: Array<String>, private val email: Array<String>, private val phone: Array<String>){
    
}




